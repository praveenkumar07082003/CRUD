const db = require('../config/database');

class Patient {
  static async create({ name, age, date_of_joining, email, phone }) {
    const [result] = await db.execute(
      'INSERT INTO patients (name, age, date_of_joining, email, phone) VALUES (?, ?, ?, ?, ?)',
      [name, age, date_of_joining, email, phone]
    );
    return result.insertId;
  }

  static async findAll() {
    const [rows] = await db.execute('SELECT * FROM patients ORDER BY id DESC');
    return rows;
  }

  static async findById(id) {
    const [rows] = await db.execute('SELECT * FROM patients WHERE id = ?', [id]);
    return rows[0];
  }

  static async update(id, { name, age, date_of_joining, email, phone }) {
    const [result] = await db.execute(
      'UPDATE patients SET name = ?, age = ?, date_of_joining = ?, email = ?, phone = ? WHERE id = ?',
      [name, age, date_of_joining, email, phone, id]
    );
    return result.affectedRows;
  }

  static async delete(id) {
    const [result] = await db.execute('DELETE FROM patients WHERE id = ?', [id]);
    return result.affectedRows;
  }
}

module.exports = Patient;
