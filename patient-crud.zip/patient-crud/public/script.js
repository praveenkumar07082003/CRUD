const apiBase = '/api/patients';

async function fetchPatients(q) {
  const url = q ? `${apiBase}?search=${encodeURIComponent(q)}` : apiBase;
  const res = await fetch(url);
  const data = await res.json();
  return data.data || data;
}

async function loadPatients() {
  const data = await fetchPatients();
  const tbody = document.querySelector('#patientsTable tbody');
  tbody.innerHTML = '';
  data.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.id}</td>
      <td>${p.name}</td>
      <td>${p.age}</td>
      <td>${p.date_of_joining || p.dateOfJoining}</td>
      <td>${p.email}</td>
      <td>${p.phone}</td>
      <td>
        <button data-id="${p.id}" class="editBtn">Edit</button>
        <button data-id="${p.id}" class="delBtn">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  attachRowButtons();
}

function attachRowButtons() {
  document.querySelectorAll('.editBtn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      const res = await fetch(apiBase + '/' + id);
      const json = await res.json();
      const p = json.data;
      document.getElementById('patientId').value = p.id;
      document.getElementById('name').value = p.name;
      document.getElementById('age').value = p.age;
      document.getElementById('dateOfJoining').value = (p.date_of_joining || p.dateOfJoining || '').split('T')[0];
      document.getElementById('email').value = p.email;
      document.getElementById('phone').value = p.phone;
    });
  });

  document.querySelectorAll('.delBtn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      if (!confirm('Delete this patient?')) return;
      const id = e.target.dataset.id;
      await fetch(apiBase + '/' + id, { method: 'DELETE' });
      loadPatients();
    });
  });
}

document.getElementById('patientForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('patientId').value;
  const payload = {
    name: document.getElementById('name').value,
    age: document.getElementById('age').value,
    dateOfJoining: document.getElementById('dateOfJoining').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value
  };
  if (id) {
    await fetch(apiBase + '/' + id, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  } else {
    await fetch(apiBase + '/', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  }
  document.getElementById('patientForm').reset();
  document.getElementById('patientId').value = '';
  loadPatients();
});

document.getElementById('clearBtn').addEventListener('click', (e) => {
  document.getElementById('patientForm').reset();
  document.getElementById('patientId').value = '';
});

document.getElementById('search').addEventListener('input', (e) => {
  const q = e.target.value.trim();
  if (!q) loadPatients();
  else fetchPatients(q).then(data => {
    const tbody = document.querySelector('#patientsTable tbody');
    tbody.innerHTML = '';
    (data || []).forEach(p => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${p.id}</td>
        <td>${p.name}</td>
        <td>${p.age}</td>
        <td>${p.date_of_joining || p.dateOfJoining}</td>
        <td>${p.email}</td>
        <td>${p.phone}</td>
        <td>
          <button data-id="${p.id}" class="editBtn">Edit</button>
          <button data-id="${p.id}" class="delBtn">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
    attachRowButtons();
  });
});

// initial load
loadPatients();
