const express = require('express');
const router = express.Router();
const Patient = require('../models/Patient');

// GET all
router.get('/', async (req, res, next) => {
  try {
    const rows = await Patient.findAll();
    res.json({ success: true, data: rows });
  } catch (err) { next(err); }
});

// GET by id
router.get('/:id', async (req, res, next) => {
  try {
    const patient = await Patient.findById(req.params.id);
    if (!patient) return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, data: patient });
  } catch (err) { next(err); }
});

// CREATE
router.post('/', async (req, res, next) => {
  try {
    const { name, age, dateOfJoining, email, phone } = req.body;
    // Basic validation
    if (!name || !age || !dateOfJoining || !email || !phone) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }
    const id = await Patient.create({
      name,
      age: parseInt(age, 10),
      date_of_joining: dateOfJoining,
      email,
      phone
    });
    res.status(201).json({ success: true, message: 'Created', id });
  } catch (err) { next(err); }
});

// UPDATE
router.put('/:id', async (req, res, next) => {
  try {
    const { name, age, dateOfJoining, email, phone } = req.body;
    const affected = await Patient.update(req.params.id, {
      name, age: parseInt(age,10), date_of_joining: dateOfJoining, email, phone
    });
    if (!affected) return res.status(404).json({ success: false, message: 'Not found or no change' });
    res.json({ success: true, message: 'Updated' });
  } catch (err) { next(err); }
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  try {
    const affected = await Patient.delete(req.params.id);
    if (!affected) return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, message: 'Deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
