const express = require('express');
const cors = require('cors');
require('dotenv').config();
const path = require('path');

const db = require('./config/database'); // ensures pool created
const patientRoutes = require('./routes/patients');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend
app.use('/', express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api/patients', patientRoutes);

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await db.query('SELECT 1'); // quick DB check
    res.json({ success: true, database: 'Connected', timestamp: new Date().toISOString() });
  } catch (err) {
    res.json({ success: false, database: 'Disconnected', error: err.message });
  }
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ success: false, message: err.message });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Open http://localhost:${PORT} to view the frontend`);
});
